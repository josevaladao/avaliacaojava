package avaliacao.persistencia;

public class TesteDeConexao {
	public static void main(String[] args) {
		Dao dao = new Dao();
		dao.open();
		System.out.println("Conex�o bem sucedida!");
		dao.close();
	}

}
