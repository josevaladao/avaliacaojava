package avaliacao.persistencia;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import avaliacao.entidade.Cliente;


public class ClienteDao extends Dao{
	
	public void cadastrarCliente(Cliente cliente) throws SQLException {
		open();
		String sql = "insert into tb_cliente(cod_cliente,nome_cliente,status_cliente)values(?,?,?)";
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, cliente.getCodCliente());
		stmt.setString(2, cliente.getNomeCliente());
		stmt.setString(3, cliente.getStatusCliente());
		stmt.execute();		
		close();
	}
	public void atualizarCliente(Cliente cliente) throws SQLException {
		open();
		String sql = "update tb_cliente set nome_cliente = ?, status_cliente = ?  where cod_cliente = ?";
		stmt = con.prepareStatement(sql);		
		stmt.setString(1, cliente.getNomeCliente());
		stmt.setString(2, cliente.getStatusCliente());
		stmt.setInt(3, cliente.getCodCliente());
		stmt.execute();		
		close();
	}
	public void excluirCliente(Cliente cliente) throws SQLException {
		open();
		String sql = "delete from tb_cliente where cod_cliente = ?";
		stmt = con.prepareStatement(sql);		
		stmt.setLong(1, cliente.getCodCliente());
		stmt.execute();		
		close();
	}
	public List<Cliente> listarCliente() throws SQLException{
		open();
		String sql = "select * from tb_cliente";
		stmt = con.prepareStatement(sql);
		rs = stmt.executeQuery();
		List<Cliente> cli = new ArrayList<Cliente>();
		
		while (rs.next()) {
			Cliente cliente = new Cliente();
			cliente.setCodCliente(rs.getInt("cod_cliente"));
			cliente.setNomeCliente(rs.getString("nome_cliente"));
			cliente.setStatusCliente(rs.getString("status_cliente"));
			cli.add(cliente);
		}
		close();
		return cli;
	}

}
