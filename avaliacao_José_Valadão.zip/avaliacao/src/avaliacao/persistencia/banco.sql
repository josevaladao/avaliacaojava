create database atlan094_teste;

use atlan094_teste;

create table tb_cliente(
	cod_cliente int not null primary key,
	nome_cliente varchar(25),
	status_cliente varchar(10)
);