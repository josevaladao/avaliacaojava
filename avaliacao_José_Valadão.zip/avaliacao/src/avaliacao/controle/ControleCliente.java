package avaliacao.controle;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import avaliacao.persistencia.ClienteDao;
import avaliacao.entidade.Cliente;

@WebServlet(name = "/ControleCliente", urlPatterns = { "/CadastrarCliente", "/AtualizarCliente", "/ExcluirCliente",
		"/ListarCliente" })
public class ControleCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ControleCliente() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	protected void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Pegando uma URL que chamou a Servlet
			String url = request.getServletPath();
			if (url.equalsIgnoreCase("/CadastrarCliente")) {
				cadastrar(request, response);
			} else if (url.equalsIgnoreCase("/AtualizarCliente")) {
				atualizar(request, response);
			} else if (url.equalsIgnoreCase("/ExcluirCliente")) {
				excluir(request, response);
			}else if (url.equalsIgnoreCase("/ListarCliente")) {
				listar(request, response);
			} else {
				throw new Exception("URL Inv�lida!!!");
			}
		} catch (Exception e) {
			response.sendRedirect("cadastraCliente.jsp");
			e.printStackTrace();
		}
	}

	protected void cadastrar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Pegar os dados do formul�rio
		String codCliente = request.getParameter("codCliente");
		String nomeCliente = request.getParameter("nomeCliente");
		String statusCliente = request.getParameter("statusCliente");

		// Instanciando um objeto do tipo Cliente e passando os dados do formul�rio
		// contidos nas vari�veis acima para o m�todo set da Classe Cliente
		Cliente cliente = new Cliente();
		cliente.setCodCliente(new Integer(codCliente));
		cliente.setNomeCliente(nomeCliente);
		cliente.setStatusCliente(statusCliente);

		// Instanciando um Objeto do tipo ClienteDao e passando o objeto Cliente para o
		// m�todo
		// de ClienteDao (adicionaCliente)
		try {
			ClienteDao cd = new ClienteDao();
			cd.cadastrarCliente(cliente);
			// Imprimindo uma mensagem de sucesso do cadastro
			request.setAttribute("msg", "Cliente cadastrado com sucesso!!!");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "Cliente n�o foi cadastrado!!!");
		}
	}

	protected void atualizar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Pegar os dados do formul�rio
		String nomeCliente = request.getParameter("nomeCliente");
		String statusCliente = request.getParameter("statusCliente");
		String codCliente = request.getParameter("codCliente");

		// Instanciando um objeto do tipo Cliente e passando os dados do formul�rio
		// contidos nas vari�veis acima para o m�todo set da Classe Cliente
		Cliente cliente = new Cliente();

		cliente.setNomeCliente(nomeCliente);
		cliente.setStatusCliente(statusCliente);
		cliente.setCodCliente(new Integer(codCliente));

		// Instanciando um Objeto do tipo ClienteDao e passando o objeto Cliente para o
		// m�todo
		// de ClienteDao
		try {
			ClienteDao cd = new ClienteDao();
			cd.atualizarCliente(cliente);
			// Imprimindo uma mensagem de sucesso do cadastro
			request.setAttribute("msg", "Cliente atualizado com sucesso!!!");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "Cliente n�o atualizado!!!");
		}

	}

	protected void excluir(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Pegar os dados do formul�rio
		String codCliente = request.getParameter("codCliente");

		// Instanciando um objeto do tipo Cliente e passando os dados do formul�rio
		// contidos nas vari�veis acima para o m�todo set da Classe Cliente
		Cliente cliente = new Cliente();
		cliente.setCodCliente(new Integer(codCliente));

		// Instanciando um Objeto do tipo ClienteDao e passando o objeto Cliente para o
		// m�todo
		// de ClienteDao
		try {

			ClienteDao dao = new ClienteDao();
			dao.excluirCliente(cliente);
			// Imprimindo uma mensagem de sucesso do cadastro
			request.setAttribute("msg", "Cliente Exclu�do com sucesso!!!");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "Cliente N�o exclu�do!!!");
		}

	}
	
	protected void listar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			
			ClienteDao cd = new ClienteDao();

			List<Cliente> lista = cd.listarCliente();

			if (lista.size() == 0) {
				request.setAttribute("msg", "Nenhum Cliente Encontrado!");
			}			
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("/listaCliente.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
